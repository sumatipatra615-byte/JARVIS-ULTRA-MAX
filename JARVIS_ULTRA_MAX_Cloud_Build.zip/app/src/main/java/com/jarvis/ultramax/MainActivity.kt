package com.jarvis.ultramax

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(0xFF050A10.toInt())
        }
        val title = TextView(this).apply {
            text = "🤖 JARVIS ULTRA MAX"
            textSize = 26f
            setTextColor(0xFF00FFD0.toInt())
        }
        val info = TextView(this).apply {
            text = "\nAndroid 13 • Right-edge pull handle\n\nEnable overlay permission, then start the floating panel. Open any game and swipe the handle left to reveal the panel."
            textSize = 16f
            setTextColor(0xFFE2F7F4.toInt())
        }
        val permission = Button(this).apply {
            text = "1. Enable Floating Permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permission already enabled", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "2. Start JARVIS Floating Handle"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Enable floating permission first", Toast.LENGTH_LONG).show()
                } else {
                    val i = Intent(this@MainActivity, FloatingPanelService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                    Toast.makeText(this@MainActivity, "JARVIS handle started", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Stop Floating Panel"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingPanelService::class.java)) }
        }
        listOf(title, info, permission, start, stop).forEach {
            root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 22 })
        }
        setContentView(root)
    }
}
