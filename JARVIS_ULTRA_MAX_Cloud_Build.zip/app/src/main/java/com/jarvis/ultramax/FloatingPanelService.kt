package com.jarvis.ultramax

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

class FloatingPanelService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private var handle: TextView? = null
    private var panel: LinearLayout? = null
    private var panelAdded = false
    private var tts: TextToSpeech? = null
    private var voiceIndex = 1
    private var gameMode = false
    private var handleParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        startAsForeground()
        addHandle()
    }

    private fun startAsForeground() {
        val channelId = "jarvis_floating"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "JARVIS Floating Panel", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("JARVIS ULTRA MAX is running")
                .setContentText("Swipe the right-edge handle left to open Game Panel")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("JARVIS ULTRA MAX is running")
                .setContentText("Floating Game Panel active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        }
        startForeground(41, notification)
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addHandle() {
        val h = TextView(this).apply {
            text = "J\nA\nR"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFF00110E.toInt())
            setBackgroundColor(0xFF00FFD0.toInt())
            setPadding(8, 18, 8, 18)
            elevation = 12f
        }
        val p = WindowManager.LayoutParams(
            dp(34), dp(112), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            x = 0; y = 0
        }
        handleParams = p
        var downX = 0f
        var downY = 0f
        h.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; true }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (dx < -35 || abs(dy) > dp(30)) showPanel()
                    else showPanel()
                    true
                }
                else -> true
            }
        }
        handle = h
        wm.addView(h, p)
    }

    private fun showPanel() {
        if (panelAdded) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xF20A1720.toInt())
            elevation = 18f
        }
        val head = TextView(this).apply {
            text = "🤖 JARVIS GAME PANEL"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF00FFD0.toInt())
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(head)
        val close = Button(this).apply { text = "Close Panel"; setOnClickListener { hidePanel() } }
        val mode = Button(this).apply {
            text = "🎮 Game Mode: OFF"
            setOnClickListener {
                gameMode = !gameMode
                text = if (gameMode) "🎮 Game Mode: ON" else "🎮 Game Mode: OFF"
                Toast.makeText(this@FloatingPanelService,
                    "Game Mode is a quick-profile toggle; it does not change protected system performance settings.",
                    Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(mode)
        val voiceTitle = TextView(this).apply {
            text = "🎙 Voice Presets (JARVIS speech)"
            setTextColor(0xFFE9FFFF.toInt())
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(voiceTitle)
        val voices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 1..9) {
            val b = Button(this).apply {
                text = i.toString()
                setOnClickListener {
                    voiceIndex = i
                    say("Voice preset $i selected, Boss")
                    Toast.makeText(this@FloatingPanelService, "Preset $i selected", Toast.LENGTH_SHORT).show()
                }
            }
            voices.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(voices)
        val sayButton = Button(this).apply {
            text = "🤖 JARVIS Speak"
            setOnClickListener { this@FloatingPanelService.say("Hello Boss. JARVIS is ready. Game panel is active.") }
        }
        root.addView(sayButton)
        val note = TextView(this).apply {
            text = "\nGame Booster: quick access panel only. Android does not allow a normal app to force GPU/CPU overclock or control another game's audio input."
            textSize = 12f
            setTextColor(0xFFB8D2D0.toInt())
        }
        root.addView(note)
        root.addView(close)
        val params = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            x = dp(42); y = 0
        }
        panel = root
        wm.addView(root, params)
        panelAdded = true
    }

    private fun hidePanel() {
        if (panelAdded) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
            panelAdded = false
        }
    }

    private fun say(message: String) {
        val engine = tts ?: return
        // Android TTS supports pitch/rate adjustments; this is not a live microphone voice changer.
        val pitch = 0.65f + (voiceIndex * 0.09f)
        engine.setPitch(pitch)
        engine.setSpeechRate(0.88f + (voiceIndex * 0.025f))
        engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_speech")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "IN")
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        hidePanel()
        try { handle?.let { wm.removeView(it) } } catch (_: Exception) {}
        handle = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
