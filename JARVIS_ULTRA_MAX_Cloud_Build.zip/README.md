# JARVIS ULTRA MAX — Android 13 starter project

This is a native Kotlin Android Studio starter project with a right-edge floating handle and a pull/swipe-to-open game panel.

## Included
- Android overlay permission flow
- Foreground service notification while the handle is active
- Right-edge JARVIS handle; swipe/tap to open panel
- Close button
- Game Mode quick-profile toggle (UI state only)
- Nine JARVIS text-to-speech pitch/rate presets
- Bengali (India) TTS language request

## Important limitations
- This is source code, not a compiled APK.
- A regular Android app cannot force CPU/GPU overclocking or guarantee higher FPS.
- The nine voice presets adjust JARVIS TTS playback only. They do not change live microphone audio inside other games.
- Some games may block overlays or restrict their use. Respect each game's rules.
- Android device vendors may kill background services; allow the app to run in the background if needed.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Let Gradle sync. Use JDK 17.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android 13 phone.
5. Open JARVIS ULTRA MAX, grant "Display over other apps", then tap Start.
6. Swipe/tap the cyan handle on the right edge to open the panel.

Target SDK 33, minimum SDK 23.

## Build an APK from a phone (cloud build)
This project includes a GitHub Actions workflow at `.github/workflows/android.yml`.
1. Create a GitHub account and a new repository.
2. Upload the contents of this ZIP to the repository (keep the `.github/workflows/android.yml` path).
3. Open the repository's **Actions** tab and run **Build JARVIS ULTRA MAX APK** (or wait for the upload-triggered build).
4. When the run finishes, open it and download the `JARVIS-ULTRA-MAX-debug-APK` artifact.
5. Extract the downloaded artifact ZIP; install `app-debug.apk` on your Android phone.

The build produces a debug APK, not a Play Store release. The first build needs internet access to download Gradle/Android dependencies.
